package autosuggestiondropdown;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.chetandaulani.core.framework.CustomDriver;
import com.chetandaulani.core.framework.Element;
import com.chetandaulani.core.framework.Wait;
import com.chetandaulani.utilities.BasePage;

public class AutoCompletePage extends BasePage {

	public AutoCompletePage(CustomDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	private By fromInputBy = By.xpath("//input[@id='searchbox']");
	private By dropdownCities = By.xpath("//input[@id='searchbox']/ancestor::div/following-sibling::div//li");

	public void setSearchInput(String from) throws InterruptedException {
		Thread.sleep(6000);
		driver.findElement(fromInputBy).sendKeys(from);
	}
	
	public void selectSecondLastElement() {
		List<WebElement> list = driver.locateVisibleElements(dropdownCities);
		int secondLast = list.size()-2;
	    list.get(secondLast).click();
	}
}
