package com.chetandaulani.ecommerce;

import org.openqa.selenium.By;
import com.chetandaulani.core.framework.CustomDriver;
import com.chetandaulani.resources.ConfigReader;
import abstractcomponents.AbstractComponents;

public class LoginPage extends AbstractComponents {

	public LoginPage(CustomDriver driver) {
		super(driver);
	}

	public ProductCataloguePage loginWith(String role) {
		String username = ConfigReader.getProperty(role);
		String password = ConfigReader.getProperty(role + "_PASSWORD");
		setUsername(username);
		setPassword(password);
		login();
		return new ProductCataloguePage(driver);
	}

	public ProductCataloguePage loginWithIncorrectPassword(String role) {
		String username = ConfigReader.getProperty(role);
		String password = ConfigReader.getProperty(role + "_PASSWORD");
		setUsername(username);
		setPassword(password + "making password incorrect");
		login();
		return new ProductCataloguePage(driver);
	}

	private void setUsername(String username) {
		By userNameBy = By.xpath("//input[@id='userEmail']");
		driver.locateVisibleElement(userNameBy).sendKeys(username);

	}

	private void setPassword(String password) {
		By passwordBy = By.xpath("//input[@placeholder='enter your passsword']");
		driver.locateVisibleElement(passwordBy).sendKeys(password);
	}

	private void login() {
		By loginBy = By.xpath("//*[@name='login']");
		driver.locateVisibleElement(loginBy).click();
	}

	public boolean isToastMessageDisplayed() {
		By toastMessageBy = By.cssSelector("#toast-container");
		return driver.locateVisibleElement(toastMessageBy).isDisplayed();
	}

}
