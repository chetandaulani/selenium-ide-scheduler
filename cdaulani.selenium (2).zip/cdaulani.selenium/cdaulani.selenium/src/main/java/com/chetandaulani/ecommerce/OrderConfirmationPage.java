package com.chetandaulani.ecommerce;

import org.openqa.selenium.By;

import com.chetandaulani.core.framework.CustomDriver;

import abstractcomponents.AbstractComponents;

public class OrderConfirmationPage extends AbstractComponents {
	public OrderConfirmationPage(CustomDriver driver) {
		super(driver);
	}

	private String productName = "//table[@class='order-summary']//div[@class='title' and translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz') = '%s']";
	private By ordersBy = By.xpath("//button[contains(text(),'ORDERS')]");

	public boolean isProductNameDisplayed(String expectedProductName) {
		return super.isProductNameDisplayed(productName, expectedProductName);
	}

	public OrdersHistoryPage goToOrdersHistoryPage() {
		driver.locateEnabledElement(ordersBy).jsClick();
		return new OrdersHistoryPage(driver);
	}

}
