package com.chetandaulani.ecommerce;

import com.chetandaulani.core.framework.CustomDriver;
import abstractcomponents.AbstractComponents;

public class OrdersHistoryPage extends AbstractComponents {
	public OrdersHistoryPage(CustomDriver driver) {
		super(driver);
	}

	String productName = "//h1[translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz') = 'your orders']/parent::div//tr/td[translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz') = '%s']";

	public boolean isProductNameDisplayed(String expectedProductName) {
		return super.isProductNameDisplayed(productName, expectedProductName);
	}

}
