package irctc;

import org.openqa.selenium.By;

import com.chetandaulani.core.framework.CustomDriver;
import com.chetandaulani.utilities.BasePage;

public class LoginPage extends BasePage {

	public LoginPage(CustomDriver driver) {
		super(driver);
	}
	
	private By optionIconBy = By.xpath("//*[@class='h_container_sm']//a");
	private By loginBy = By.xpath("//button[text()='LOGIN']");
	private By usernameBy = By.xpath("//input[@placeholder='User Name']");
	private By passwordBy = By.xpath("//input[@placeholder='Password']");
	private By signinBy = By.xpath("//button[text()='SIGN IN']");

	public void goToLoginPage() {
		driver.locateEnabledElement(optionIconBy).click();
		driver.locateEnabledElement(loginBy).click();
	}

	public void fillLoginDetails(String username, String password) {
		setUsername(username); 
		setPassword(password);
	}

	private void setUsername(String username) {
		driver.locateVisibleElement(usernameBy).sendKeys(username);
	}

	private void setPassword(String password) {
		driver.locateVisibleElement(passwordBy).sendKeys(password);
	}
	
	public LandingPage signIn() {
		driver.locateVisibleElement(signinBy).jsClick();
		return new LandingPage(driver);
	}


}
