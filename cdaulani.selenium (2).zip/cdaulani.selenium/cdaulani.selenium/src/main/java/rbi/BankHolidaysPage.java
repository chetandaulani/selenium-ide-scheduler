package rbi;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BankHolidaysPage {

	private WebDriver driver;
	private WebDriverWait wait;

	public BankHolidaysPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
	}

	private By regionalOfficeBy = By.xpath("//select[@id='drRegionalOffice']");
	private By monthBy = By.xpath("//select[@id='drMonth']");
	private By goBy = By.xpath("//input[@value='GO']");
	private By monthDataBy = By.xpath("//td[@class='tableheader']/b");
	private String holidayDataList = "//table//b[contains(text(),'%s')]/ancestor::tr/following-sibling::tr/td";

	public void selectRegionaOffice(String regionalOffice) {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(regionalOfficeBy));
		Select select = new Select(element);
		select.selectByVisibleText(regionalOffice);
	}

	public void selectMonth(String month) {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(monthBy));
		Select select = new Select(element);
		select.selectByVisibleText(month);
	}

	public void go() {
		wait.until(ExpectedConditions.elementToBeClickable(goBy));
		driver.findElement(goBy).click();
	}

	public void storeDataAsTextFile(List<WebElement> monthsList) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("holidayData.txt"))) {
			for (int i = 0; i < monthsList.size(); i++) {
				By holidayDataListBy = By.xpath(String.format(holidayDataList, monthsList.get(i).getText()));
				List<WebElement> allDatas = wait
						.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(holidayDataListBy));
				for (int j = 0; j < allDatas.size(); j++) {
					if (i < monthsList.size() - 1 && allDatas.get(j).getText().equals(monthsList.get(i + 1))) {
						break;
					}
					if (allDatas.get(j).getText().equals("•")) {
						writer.newLine();
						continue;
					}
					if(j%2==0)
						writer.write("," + allDatas.get(j).getText());
					else
					writer.write(monthsList.get(i).getText() + "," + allDatas.get(j).getText());
			
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public List<WebElement> getMonths() {
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(monthDataBy));
		return driver.findElements(monthDataBy);
	}

}
