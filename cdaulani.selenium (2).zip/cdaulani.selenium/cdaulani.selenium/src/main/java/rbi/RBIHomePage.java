package rbi;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RBIHomePage {
	private WebDriver driver;
	private WebDriverWait wait;

	public RBIHomePage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
	}

	private By rememberMyChoiceBy = By.xpath("//label[contains(text(),'Remember my choice')]/preceding-sibling::input");
	private By englishBy = By.xpath("//button[text()='English']");
    private By bankHolidaysBy = By.xpath("//ul[@class='footerlist']//a[text()='Bank Holidays']");
    
    public void openRBIHomePage() {
    	driver.get("https://www.rbi.org.in/");
    }
    
	public void chooseEnglish() {
		if (isRememberMyChoiceDisplayed(rememberMyChoiceBy)) {
			selectRememberMyChoice();
			english();
		}
	}

	private void selectRememberMyChoice() {
		wait.until(ExpectedConditions.elementToBeClickable(rememberMyChoiceBy));
		driver.findElement(rememberMyChoiceBy);
	}

	private void english() {
		wait.until(ExpectedConditions.elementToBeClickable(englishBy));
		driver.findElement(englishBy).click();
	}

	private boolean isRememberMyChoiceDisplayed(By by) {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(by));
		} catch (TimeoutException e) {
			return false;
		}
		return true;
	}
	
	public BankHolidaysPage goToBankHolidaysPage() {
		bankHolidays();
		return new BankHolidaysPage(driver);
	}
	
	private void bankHolidays() {
		scrollToBottom(bankHolidaysBy);
		wait.until(ExpectedConditions.elementToBeClickable(bankHolidaysBy));
		driver.findElement(bankHolidaysBy).click();
	}

	private void scrollToBottom(By by) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
	}

}
