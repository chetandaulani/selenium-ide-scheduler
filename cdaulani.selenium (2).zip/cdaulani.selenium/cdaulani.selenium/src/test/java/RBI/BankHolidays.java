package RBI;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import rbi.RBIHomePage;

public class BankHolidays {

	@Test
	public void extractBankHolidayDataAsTextFile() {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		var rbiHomePage = new RBIHomePage(driver);
		rbiHomePage.openRBIHomePage();
		rbiHomePage.chooseEnglish();
		var bankHolidaysPage = rbiHomePage.goToBankHolidaysPage();
		bankHolidaysPage.selectRegionaOffice("Mumbai");
		bankHolidaysPage.selectMonth("All Months");
		bankHolidaysPage.go();
		List<WebElement> months = bankHolidaysPage.getMonths();
		bankHolidaysPage.storeDataAsTextFile(months);
	}

}
