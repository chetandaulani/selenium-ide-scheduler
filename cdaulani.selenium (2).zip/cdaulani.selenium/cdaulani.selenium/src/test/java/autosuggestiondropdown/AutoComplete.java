package autosuggestiondropdown;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.chetandaulani.browserconfiguration.TestEnvironment;

public class AutoComplete extends TestEnvironment{
	@Test
	public void selectFromDropdown() throws InterruptedException {
		AutoCompletePage ta = new AutoCompletePage(getCustomDriver());
		ta.setSearchInput("a");
		ta.selectSecondLastElement();
		Thread.sleep(20000);
	}
}
