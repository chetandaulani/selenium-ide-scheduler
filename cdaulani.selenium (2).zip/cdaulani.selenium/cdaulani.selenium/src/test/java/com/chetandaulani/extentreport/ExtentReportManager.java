package com.chetandaulani.extentreport;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportManager implements ITestListener {

	ExtentSparkReporter spark;
	ExtentReports extent;
	ExtentTest test;

	@Override
	public void onStart(ITestContext context) {
		spark = new ExtentSparkReporter(System.getProperty("user.dir")+"/test-output/farzi.html");
		spark.config().setDocumentTitle("Automation Test Report");
		spark.config().setReportName("Selenium Test Execution Report");
		spark.config().setTheme(Theme.DARK);

		extent = new ExtentReports();
		extent.attachReporter(spark);
		extent.setSystemInfo("Tester", "QA Engineer");
		extent.setSystemInfo("Browser", "Chrome");
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		test = extent.createTest(result.getName());
		test.log(Status.PASS, "Test case passed" + result.getName());
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		test = extent.createTest(result.getName());
		test.log(Status.SKIP, "Test case skipped" + result.getName());
	}

	@Override
	public void onTestFailure(ITestResult result) {
		test = extent.createTest(result.getName());
		test.log(Status.FAIL, "Test case failed " + result.getName());
		//take screenshot
	}

	@Override
	public void onFinish(ITestContext context) {
		extent.flush();
	}

}
