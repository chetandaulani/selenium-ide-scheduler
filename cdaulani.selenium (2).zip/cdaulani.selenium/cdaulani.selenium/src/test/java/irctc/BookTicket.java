package irctc;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.chetandaulani.browserconfiguration.TestEnvironment;
import irctc.LoginPage;

public class BookTicket extends TestEnvironment {

	@Parameters({ "username", "password" })
	@Test
	public void bookTicket(String username, String password) throws InterruptedException {
		var loginPage = new LoginPage(getCustomDriver());
		loginPage.goToLoginPage();
		loginPage.fillLoginDetails(username, password);
		Thread.sleep(8000);
		loginPage.signIn();
		
		Thread.sleep(10000);

	}
}
