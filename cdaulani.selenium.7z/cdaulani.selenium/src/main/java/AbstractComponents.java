import com.chetandaulani.core.framework.CustomDriver;
import com.chetandaulani.utilities.BasePage;

public class AbstractComponents extends BasePage {

	public AbstractComponents(CustomDriver driver) {
		super(driver);
	}

	public boolean isProductNameDisplayed(String xpath, String expectedProductName) {
		return driver.locateVisibleElement(ByTemplate(xpath, expectedProductName)).isDisplayed();
	}
	
	

}
