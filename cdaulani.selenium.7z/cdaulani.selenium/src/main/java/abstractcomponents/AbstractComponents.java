package abstractcomponents;

import org.openqa.selenium.By;

import com.chetandaulani.core.framework.CustomDriver;
import com.chetandaulani.utilities.BasePage;

public class AbstractComponents extends BasePage {

	public AbstractComponents(CustomDriver driver) {
		super(driver);
	}

	// Incorrect email or password.
	private String toastTemplate = "//div[@id='toast-container' and contains(.,'%s')]";

	public boolean isToastMessageDisplayed(String toastMessage) {
		By toastMessageBy = ByTemplate(toastTemplate, toastMessage);
		return driver.locateVisibleElement(toastMessageBy).isDisplayed();
	}

	public boolean isProductNameDisplayed(String xpath, String expectedProductName) {
		return driver.locateVisibleElement(ByTemplate(xpath, expectedProductName.toLowerCase())).isDisplayed();
	}

}
