package actionsclass;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.chetandaulani.core.framework.CustomDriver;
import com.chetandaulani.core.framework.Element;
import com.chetandaulani.utilities.BasePage;

public class mouseAndKeyboardActions extends BasePage {

	public mouseAndKeyboardActions(CustomDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	private By widgetsBy = By.xpath("//a[text()='Widgets']");
	private By sliderBy = By.xpath("//a[text()=' Slider ']");
	private By sliderIconBy = By.xpath("//div[@id='slider']/a");

	public void goToSliderPage() throws InterruptedException {
		Actions act = new Actions(driver.getWebDriver());
		wait.untilElementEnabled(widgetsBy);
		WebElement el = driver.findElement(widgetsBy);
		act.moveToElement(el).perform();
		wait.untilElementVisible(sliderBy);
		driver.findElement(sliderBy).click();

		wait.untilElementEnabled(sliderIconBy);
		WebElement sliderIconElement = driver.findElement(sliderIconBy);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].style.left = '70%';", sliderIconElement);

		js.executeScript("window.scrollBy(0, 100);");
	}

}
