package com.chetandaulani.ecommerce;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.chetandaulani.core.framework.CustomDriver;
import com.chetandaulani.utilities.BasePage;

public class CartPage extends BasePage {
	public CartPage(CustomDriver driver) {
		super(driver);
	}

	private By cartProductsBy = By.cssSelector(".cart li");
	private By checkoutBy = By.xpath("//button[text()='Checkout']");

	public boolean isExpectedProductAdded(String productName) {
		List<WebElement> cartProducts = driver.locateVisibleElements(cartProductsBy);
		boolean matchFound = cartProducts.stream()
				.anyMatch(product -> product.findElement(By.tagName("h3")).getText().equals(productName));
		return matchFound;
	}

	public CheckoutPage goToCheckout() {
		scrollToLazyLoadElement(checkoutBy);
		driver.locateEnabledElement(checkoutBy).click();
		return new CheckoutPage(driver);
	}

}
