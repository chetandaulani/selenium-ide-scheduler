package com.chetandaulani.ecommerce;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.chetandaulani.core.framework.CustomDriver;
import com.chetandaulani.utilities.BasePage;

public class CheckoutPage extends BasePage {
	public CheckoutPage(CustomDriver driver) {
		super(driver);
	}

	private By countryBy = By.xpath("//input[@placeholder='Select Country']");
	private By autoSuggestionBy = By.xpath("//section[contains(@class,'ta-results')]//span");
	private By placeHolderBy = By.xpath("//a[contains(text(),'Place Order ')]");

	public void setCountry(String country) {
		driver.locateVisibleElement(countryBy).sendKeys(country);
	}

	public void selectAutoSuggestion(String country) {
		List<WebElement> list = driver.locateVisibleElements(autoSuggestionBy);
		for (WebElement element : list) {
			if (element.getText().trim().equalsIgnoreCase(country)) {
				element.click();
				break;
			}
		}
	}

	public OrderConfirmationPage goToOrderConfirmationPage() {
		placeOrder();
		return new OrderConfirmationPage(driver);
	}

	private void placeOrder() {
		scrollToLazyLoadElement(placeHolderBy);
		driver.locateVisibleElement(placeHolderBy).click();
	}

}