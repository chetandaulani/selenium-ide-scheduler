package com.chetandaulani.ecommerce;

import java.util.List;
import org.openqa.selenium.By;
import com.chetandaulani.core.framework.CustomDriver;
import com.chetandaulani.core.framework.Element;
import com.chetandaulani.utilities.BasePage;

public class ProductCataloguePage extends BasePage {

	public ProductCataloguePage(CustomDriver driver) {
		super(driver);
	}

	private By addToCartBy = By.xpath("//button[contains(.,'Add To Cart')]");
	private String view = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '%s')]/parent::h5/following-sibling::button[text()=' View']";
	private By cartBy = By.xpath("//button[@routerlink='/dashboard/cart']");
	private By spinnerBy = By.xpath("//*[@class='ngx-spinner']/div");
	private By toastMessageBy = By.cssSelector("#toast-container");
	private By ordersBy = By.xpath("//button[contains(text(),'ORDERS')]");
	private String addToCart = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '%s')]/parent::h5/following-sibling::button[text()=' Add To Cart']";
	private String getProductName = "//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '%s')]";

	public void addToCartByName(String productName) throws InterruptedException {
		Thread.sleep(3000);
		By addToCartBy = ByTemplate(addToCart, productName);
		driver.locateElement(addToCartBy).click();
	}

	public String getAddedProductName(String productName) {
		By getProductNameBy = ByTemplate(getProductName, productName);
		return driver.locateVisibleElement(getProductNameBy).getText();
	}

	public CartPage goToCartPage() throws InterruptedException {
		viewCart();
		return new CartPage(driver);
	}

	private void viewCart() throws InterruptedException {
		Thread.sleep(3000);
		driver.locateVisibleElement(cartBy).click();
	}

	public ProductDetailsPage goToProductDetailsPage(String productName) throws InterruptedException {
		viewProductDetails(productName);
		return new ProductDetailsPage(driver);
	}

	private void viewProductDetails(String productName) throws InterruptedException {
		Thread.sleep(3000);
		By viewBy = ByTemplate(view, productName);
		driver.locateElement(viewBy).click();
	}

	public OrdersHistoryPage goToOrdersHistoryPage() {
		driver.locateEnabledElement(ordersBy).jsClick();
		return new OrdersHistoryPage(driver);
	}

}
