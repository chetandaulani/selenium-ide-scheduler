package com.chetandaulani.ecommerce;

import org.openqa.selenium.By;

import com.chetandaulani.core.framework.CustomDriver;

import abstractcomponents.AbstractComponents;

public class ProductDetailsPage extends AbstractComponents {

	public ProductDetailsPage(CustomDriver driver) {
		super(driver);
	}

	private String productNameTemplate = "//h2[text()='%s']";

	protected boolean isProductNameDisplayed(String productName) {
		return super.isProductNameDisplayed(productNameTemplate, productName);
	}

}
