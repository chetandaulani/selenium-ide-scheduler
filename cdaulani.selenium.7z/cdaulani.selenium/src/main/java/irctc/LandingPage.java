package irctc;

import com.chetandaulani.core.framework.CustomDriver;
import com.chetandaulani.utilities.BasePage;

public class LandingPage extends BasePage {

	public LandingPage(CustomDriver driver) {
		super(driver);
	}

}
