package orangehrm;

import org.openqa.selenium.WebDriver;

public class HomePage {

	public HomePage(WebDriver driver) {
		
	}

}
