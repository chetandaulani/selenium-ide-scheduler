package orangehrm;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
	WebDriver driver;
	WebDriverWait wait;

	public LoginPage(WebDriver driver) {
		super();
		this.driver = driver;
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	}

	private By userNameBy = By.xpath("//input[@placeholder='Username']");
	private By passwordBy = By.xpath("//input[@placeholder='Password']");
	private By loginBy = By.xpath("//button[@type='submit']");

	public HomePage loginWith(String username, String password) {
		navigateToLoginPage();
		setUsername(username);
		setPassword(password);
		login();
		return new HomePage(driver);

	}

	// TODO Auto-generated method stub
	private void navigateToLoginPage() {

		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}

	private void setUsername(String username) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(userNameBy));
		driver.findElement(userNameBy).sendKeys(username);
	}

	private void setPassword(String password) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(passwordBy));
		driver.findElement(passwordBy).sendKeys(password);
	}

	private void login() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(loginBy));
		driver.findElement(loginBy).click();

	}
}