package actionsclass;

import org.testng.annotations.Test;

import com.chetandaulani.browserconfiguration.TestEnvironment;

import autosuggestiondropdown.AutoCompletePage;

public class MouseAndKeyboardInteractions extends TestEnvironment{

	@Test
	public void click() throws InterruptedException {
		mouseAndKeyboardActions mka = new mouseAndKeyboardActions(getDriver());
		mka.goToSliderPage();
		
	}
}
