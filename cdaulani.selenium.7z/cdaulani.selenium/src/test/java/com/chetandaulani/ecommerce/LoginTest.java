package com.chetandaulani.ecommerce;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.chetandaulani.browserconfiguration.TestEnvironment;
import com.chetandaulani.ecommerce.LoginPage;
import com.chetandaulani.resources.CustomerIdManager;

public class LoginTest extends TestEnvironment {

	@Parameters("role")
	@Test(groups = { "smoke", "regression" })
	public void loginValidation(String role) throws InterruptedException {
		System.out.println("loginValidationTest");
		System.out.println(CustomerIdManager.getCustomerId());

		var loginPage = new LoginPage(getCustomDriver());
		var cataloguePage = loginPage.loginWith(role);
		boolean isUserLoggedIn = loginPage.isToastMessageDisplayed("Login Successfully");
		Assert.assertTrue(isUserLoggedIn, "User logged in");
	}

	@Parameters("role")
	@Test(groups = { "smoke", "regression" })
	public void errorValidation(String role) throws InterruptedException {
		System.out.println("loginErrorValidation");
		System.out.println(CustomerIdManager.getCustomerId());

		var loginPage = new LoginPage(getCustomDriver());
		loginPage.loginWithIncorrectPassword(role);
		boolean isErrorMessageDisplayed = loginPage.isToastMessageDisplayed("Incorrect email or password.");
		Assert.assertTrue(isErrorMessageDisplayed, "Incorrect email or password.");
	}
	
	
	@AfterMethod(alwaysRun=true)
	public void releaseId() throws InterruptedException {
		CustomerIdManager.releaseCustomerId();
	}

}
