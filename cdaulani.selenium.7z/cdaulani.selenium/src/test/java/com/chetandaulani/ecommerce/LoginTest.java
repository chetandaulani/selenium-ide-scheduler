package com.chetandaulani.ecommerce;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.chetandaulani.browserconfiguration.TestEnvironment;
import com.chetandaulani.ecommerce.LoginPage;

public class LoginTest extends TestEnvironment {

	@Parameters("role")
	@Test(groups = { "smoke" })
	public void loginValidation(String role) throws InterruptedException {
		System.out.println("loginValidationTest");
		var loginPage = new LoginPage(getDriver());
		var cataloguePage = loginPage.loginWith(role);
		boolean isUserLoggedIn = loginPage.isToastMessageDisplayed("Login Successfully");
		Assert.assertTrue(isUserLoggedIn, "User logged in");
	}

	@Parameters("role")
	@Test(groups = { "smoke" })
	public void errorValidation(String role) throws InterruptedException {
		System.out.println("errorValidation");
		var loginPage = new LoginPage(getDriver());
		loginPage.loginWithIncorrectPassword(role);
		boolean isErrorMessageDisplayed = loginPage.isToastMessageDisplayed("Incorrect email or password.");
		Assert.assertTrue(isErrorMessageDisplayed, "Incorrect email or password.");
	}

}
