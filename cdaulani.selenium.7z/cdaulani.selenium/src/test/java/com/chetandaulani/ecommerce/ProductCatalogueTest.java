package com.chetandaulani.ecommerce;

import java.io.IOException;
import java.util.HashMap;
import static com.chetandaulani.utilities.JsonToHashMap.*;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.chetandaulani.browserconfiguration.TestEnvironment;

public class ProductCatalogueTest extends TestEnvironment {

	@Parameters("role")
	@Test(groups = { "smoke" })
	public void viewProductDetails(String role) throws InterruptedException {
		System.out.println("viewProductDetailsTest");
		String productName = "IPHONE 13 PRO";
		var loginPage = new LoginPage(getDriver());
		var cataloguePage = loginPage.loginWith(role);
		boolean isToastMessageDisplayed = loginPage.isToastMessageDisplayed();
		Assert.assertTrue(isToastMessageDisplayed, "User logged in");
		var cartPage = cataloguePage.goToProductDetailsPage(productName);
		boolean isProductDisplayed = cartPage.isProductNameDisplayed(productName);
		Assert.assertTrue(isProductDisplayed, "Following product added is displayed at DetailsPage :" + productName);
	}

	@Parameters("role")
	@Test
	public void addToCart(String role) throws InterruptedException {
		System.out.println("addToCart");
		String productName = "IPHONE 13 PRO";
		var loginPage = new LoginPage(getDriver());
		var cataloguePage = loginPage.loginWith(role);
		boolean isToastMessageDisplayed = loginPage.isToastMessageDisplayed();
		Assert.assertTrue(isToastMessageDisplayed, "User logged in");
		cataloguePage.addToCartByName(productName);
		var cartPage = cataloguePage.goToCartPage();
		boolean isProductAddedToCart = cartPage.isExpectedProductAdded(productName);
		Assert.assertTrue(isProductAddedToCart, "Following product added to cart :" + productName);
	}

	@Test(groups = { "smoke", "placeorder" }, dataProvider = "getJsonToHashMapData")
	public void placeOrder(HashMap<String, String> data) throws InterruptedException {
		System.out.println("Executing placeOrderTest");
		System.out.println("Role: " + data.get("role"));
		System.out.println("Product: " + data.get("productName"));
		System.out.println("Country: " + data.get("country"));

		var loginPage = new LoginPage(getDriver());
		var cataloguePage = loginPage.loginWith(data.get("role"));
		cataloguePage.addToCartByName(data.get("productName"));
		String addedProductName = cataloguePage.getAddedProductName(data.get("productName"));
		var cartPage = cataloguePage.goToCartPage();
		var checkoutPage = cartPage.goToCheckout();
		checkoutPage.setCountry(data.get("country"));
		checkoutPage.selectAutoSuggestion(data.get("country"));
		var orderConfirmationPage = checkoutPage.goToOrderConfirmationPage();
		Assert.assertTrue(orderConfirmationPage.isProductNameDisplayed(addedProductName),
				"Correct product name is displayed at order confirmation page: " + addedProductName);
		var ordersPage = orderConfirmationPage.goToOrdersHistoryPage();
		Assert.assertTrue(ordersPage.isProductNameDisplayed(addedProductName),
				"Correct product name is displayed at orders page: " + addedProductName);
	}

	@Parameters("role")
	@Test(dependsOnMethods = { "placeOrder" })
	public void orderHistory(String role) throws InterruptedException {
		System.out.println("orderHistory");
		String productName = "IPHONE 13 PRO";
		var loginPage = new LoginPage(getDriver());
		var cataloguePage = loginPage.loginWith(role);
		var ordersPage = cataloguePage.goToOrdersHistoryPage();
		Assert.assertTrue(ordersPage.isProductNameDisplayed(productName),
				"Order placed is visible in the orders history page" + productName);
	}

	@DataProvider
	public Object[][] getData() {
		return new Object[][] { { "ECOMMERCE1_TEST", "IPHONE 13 PRO" }, { "ECOMMERCE2_TEST", "qwerty" } };
	}

	@DataProvider(name = "HashMap")
	public Object[][] hashmapData() {
		// Test Case 1
		HashMap<String, String> data1 = new HashMap<>();
		data1.put("role", "ECOMMERCE1_TEST");
		data1.put("productName", "iphone 13 pro".toLowerCase());
		data1.put("country", "India");

		// Test Case 2
		HashMap<String, String> data2 = new HashMap<>();
		data2.put("role", "ECOMMERCE2_TEST");
		data2.put("productName", "qwerty");
		data2.put("country", "Australia");

		return new Object[][] { { data1 }, { data2 } };
	}

	@DataProvider(name = "getJsonToHashMapData")
	public Object[][] getJsonData() throws IOException {
		return getJsonToHashMapData("\\src\\test\\resources\\testdata\\TestData.json");
	}

}
