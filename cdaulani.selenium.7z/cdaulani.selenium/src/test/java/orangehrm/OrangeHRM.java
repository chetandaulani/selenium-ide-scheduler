package orangehrm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.chetandaulani.browserconfiguration.TestEnvironment;


public class OrangeHRM {
	
	@Test
	public void login() throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		var loginPage = new LoginPage(driver);
		var homePage = loginPage.loginWith("admin", "admin123");

	}

}
