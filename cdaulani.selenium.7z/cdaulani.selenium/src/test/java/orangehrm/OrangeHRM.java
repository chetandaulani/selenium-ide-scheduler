package orangehrm;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.chetandaulani.browserconfiguration.TestEnvironment;

public class OrangeHRM {

	@Test
	public void login() throws InterruptedException {
		WebDriver driver = new ChromeDriver();
//		var loginPage = new LoginPage(driver);
//		var homePage = loginPage.loginWith("admin", "admin123");

		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

		// maximise the window
		driver.manage().window().maximize();
		// driver.findElement(By.xpath("//img[@alt='company-branding']"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username']")));
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("Admin");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();

	}

}
