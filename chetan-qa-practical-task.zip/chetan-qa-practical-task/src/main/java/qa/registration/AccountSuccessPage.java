package qa.registration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import qa.util.BasePage;

public class AccountSuccessPage extends BasePage {

	public AccountSuccessPage(WebDriver driver) {
		super(driver);
	}

	private By accountSuccessMessageBy = By.xpath("//h1[text()='Your Account Has Been Created!']");

	public boolean isAccountSuccessMessageDisplayed() {
		return findVisibleElement(accountSuccessMessageBy).isDisplayed();
	}

}
