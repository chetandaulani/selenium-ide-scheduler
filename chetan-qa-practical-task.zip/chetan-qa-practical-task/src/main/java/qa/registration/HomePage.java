package qa.registration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import qa.util.BasePage;

public class HomePage extends BasePage {

	public HomePage(WebDriver driver) {
		super(driver);
	}

	private By myAccountBy = By.xpath("//a[@title='My Account']");
	private By registerBy = By.xpath("//a[text()='Register']");

	public void myAccount() {
		findEnabledElement(myAccountBy).click();
	}
	
	public RegistrationPage goToRegistrationPage() {
		findEnabledElement(registerBy).click();
		return new RegistrationPage(driver);
	}

}
