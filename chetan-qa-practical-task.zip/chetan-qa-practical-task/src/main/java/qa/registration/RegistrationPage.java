package qa.registration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import static qa.registration.testdata.RegistrationTestData.*;

import qa.util.BasePage;

public class RegistrationPage extends BasePage {

	public RegistrationPage(WebDriver driver) {
		super(driver);
	}

	private String fieldTemplateXpath = "//input[@name='%s']";
	private By agreeBy = By.xpath("//input[@name='agree']");
    private By continueBy = By.xpath("//input[@value='Continue']");
	
	public void fillRegistrationForm(String firstName, String lastName, String email,String telephone, String password, String confirmPassword)
	{
		setFirstname(firstName);
		setLastname(lastName);
		setEmail(email);
		setTelephone(telephone);
		setPassword(password);
		setConfirmPassword(confirmPassword);
	}
	private void setFirstname(String value) {
		setField(FIRST_NAME_LABEL, value);
	}

	private void setLastname(String value) {
		setField(LAST_NAME_LABEL, value);
	}

	private void setEmail(String value) {
		setField(EMAIL_LABEL, value);
	}

	private void setPassword(String value) {
		setField(PASSWORD_LABEL, value);
	}

	private void setConfirmPassword(String value) {
		setField(CONFIRM_PASSWORD_LABEL, value);
	}

	private void setTelephone(String value) {
		setField(TELEPHONE_LABEL, value);
	}

	private void setField(String label, String value) {
		By by = By.xpath(String.format(fieldTemplateXpath, label));
		findEnabledElement(by).sendKeys(value);
	}
	
	public void agreeTerms() {
		findEnabledElement(agreeBy).click();
	}
	
	public AccountSuccessPage goToAccountSuccessPage() {
		clickContinue();
		return new AccountSuccessPage(driver);
	}
	
	private void clickContinue() {
		findEnabledElement(continueBy).click();
	}

}
