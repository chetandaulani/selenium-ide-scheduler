package qa.registration.testdata;

public class RegistrationTestData {
  //field labels to get locator	
  public static final String FIRST_NAME_LABEL="firstname";
  public static final String LAST_NAME_LABEL="lastname";
  public static final String EMAIL_LABEL="email";
  public static final String TELEPHONE_LABEL="telephone";
  public static final String PASSWORD_LABEL="password";
  public static final String CONFIRM_PASSWORD_LABEL="confirm";
  
  //test data for form
  public static final String FIRST_NAME="itachi";
  public static final String LAST_NAME="u";
  public static final String EMAIL="itachi@gmail.com";
  public static final String TELEPHONE="1234567890";
  public static final String PASSWORD="Crack@22025";
  public static final String CONFIRM_PASSWORD="Crack@22025";
  
}
