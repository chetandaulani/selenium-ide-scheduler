package qa.util;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {
	protected WebDriver driver;
	protected WebDriverWait wait;

	public BasePage(WebDriver driver) {
		super();
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}

	public WebElement findEnabledElement(By by) {
		return wait.until(ExpectedConditions.elementToBeClickable(by));
	}

	public WebElement findVisibleElement(By by) {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}

}
