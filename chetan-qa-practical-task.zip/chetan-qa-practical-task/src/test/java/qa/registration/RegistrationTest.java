package qa.registration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import static qa.registration.testdata.RegistrationTestData.*;

public class RegistrationTest {

	@Test
	public void verifyUserRegistration() {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://naveenautomationlabs.com/opencart/index.php?route=common/home");
		HomePage homePage = new HomePage(driver);
		homePage.myAccount();
		RegistrationPage registrationPage = homePage.goToRegistrationPage();
		registrationPage.fillRegistrationForm(FIRST_NAME, LAST_NAME, EMAIL, TELEPHONE, PASSWORD, CONFIRM_PASSWORD);
		registrationPage.agreeTerms();
		AccountSuccessPage accountSuccessPage = registrationPage.goToAccountSuccessPage();
		boolean isAccountCreated = accountSuccessPage.isAccountSuccessMessageDisplayed();
		Assert.assertTrue(isAccountCreated,"Your Account Has Been Created!");
	}

}
